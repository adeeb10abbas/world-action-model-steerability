Separate coauthor revision. Compile revision_esmaeil.tex. Four main pages, one references page, fourteen appendix pages. Existing main.tex is intentionally not included or replaced.
